package program5a;

	import java.util.Stack;
	import java.util.regex.Pattern;
	
	public class StringOperations {
		
		static String reverseWords(String str)
	    {
	        Pattern pattern = Pattern.compile("\\s");
	        String[] temp = pattern.split(str);
	        String result = "";
	        for (int i = 0; i < temp.length; i++) {
	            if (i == temp.length - 1)
	                result = temp[i] + result;
	            else
	                result = " " + temp[i] + result;
	        }
	        return result;
	    }
		
		
		static String firstLetterWord(String str)
	    {
	        String result = "";
	        boolean v = true;
	        for (int i = 0; i < str.length(); i++)
	        {
	            if (str.charAt(i) == ' ')
	            {
	               v = true;
	            }
	            else if (str.charAt(i) != ' ' && v == true)
	            {
	                result += (str.charAt(i));
	                v = false;
	            }
	        }
	        return result;
	    }
		  
		public static String recursiveReverse(char []str)
		 {
		   Stack<Character> st = new Stack<>();
		   for(int i=0; i<str.length; i++)
		        st.push(str[i]);
		   for (int i=0; i<str.length; i++) {
		    str[i] = st.peek();
		    st.pop();
		   }    
		   return String.valueOf(str);
		 }
		
		
		 static String reverseWords2(String str)
		    {
		        Pattern pattern = Pattern.compile("\\s");
		        String[] temp = pattern.split(str);
		        String result = "";
		        for (int i = 0; i < temp.length; i++) {
		            if (i == temp.length - 1)
		                result = temp[i] + result;
		            else
		                result = " " + temp[i] + result;
		        }
		        return result;
		    }
		
		
	    public static void main(String args[])
	    {
	        String str = "JAVA is Simple";
	        String strup = str.toUpperCase();
	        String strlow = str.toLowerCase(); 
	        System.out.println(strup);
	        System.out.println(strlow);
	        System.out.println(firstLetterWord(str));
	        System.out.println(reverseWords(str));
	        
	        str = recursiveReverse(str.toCharArray());
	        System.out.println(reverseWords2(str));
	        
	        System.out.println(str.replace(" ", "").length());
	    }

	}


